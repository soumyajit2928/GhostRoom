// Paste your Firebase web app config here (Project settings → Your apps). These values are public by design;
// security comes from database.rules.json, not from hiding this.
window.FIREBASE_CONFIG = { apiKey: "", authDomain: "", databaseURL: "", projectId: "", appId: "" };
